#
# TABLE STRUCTURE FOR: data_barang
#

DROP TABLE IF EXISTS `data_barang`;

CREATE TABLE `data_barang` (
  `id_barang` int(10) NOT NULL AUTO_INCREMENT,
  `kode_barang` varchar(100) NOT NULL,
  `nama_data_barang` varchar(100) NOT NULL,
  `id_jenis` int(10) NOT NULL,
  `id_satuan` int(10) NOT NULL,
  `id_kategori` int(10) NOT NULL,
  `keuntungan_minimum` float NOT NULL,
  `diskon_maksimum` float NOT NULL,
  `harga_beli` int(100) NOT NULL,
  `harga_jual` int(100) NOT NULL,
  `state` enum('aktif','tidak') NOT NULL,
  `id_user_input` int(10) NOT NULL,
  `tgl_input` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id_barang`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `data_barang` (`id_barang`, `kode_barang`, `nama_data_barang`, `id_jenis`, `id_satuan`, `id_kategori`, `keuntungan_minimum`, `diskon_maksimum`, `harga_beli`, `harga_jual`, `state`, `id_user_input`, `tgl_input`) VALUES (4, 'BR0000001', 'Laptop Travelmate i3 ', 1, 2, 3, '1', '1', 120000, 500000, 'aktif', 1, '2023-12-13 04:25:16');
INSERT INTO `data_barang` (`id_barang`, `kode_barang`, `nama_data_barang`, `id_jenis`, `id_satuan`, `id_kategori`, `keuntungan_minimum`, `diskon_maksimum`, `harga_beli`, `harga_jual`, `state`, `id_user_input`, `tgl_input`) VALUES (5, 'BR0000002', 'Tinta Epson 001 Yelow', 4, 2, 3, '10', '10', 50000, 60000, 'aktif', 1, '2023-12-24 04:03:56');
INSERT INTO `data_barang` (`id_barang`, `kode_barang`, `nama_data_barang`, `id_jenis`, `id_satuan`, `id_kategori`, `keuntungan_minimum`, `diskon_maksimum`, `harga_beli`, `harga_jual`, `state`, `id_user_input`, `tgl_input`) VALUES (6, 'BR0000003', 'Tinta Epson 001 Black', 5, 2, 3, '10', '10', 65000, 70000, 'aktif', 1, '2023-12-24 04:04:31');
INSERT INTO `data_barang` (`id_barang`, `kode_barang`, `nama_data_barang`, `id_jenis`, `id_satuan`, `id_kategori`, `keuntungan_minimum`, `diskon_maksimum`, `harga_beli`, `harga_jual`, `state`, `id_user_input`, `tgl_input`) VALUES (7, 'BR0000004', 'Tinta Epson 001 Magenta', 5, 2, 3, '10', '10', 620000, 700000, 'aktif', 1, '2023-12-24 04:05:00');
INSERT INTO `data_barang` (`id_barang`, `kode_barang`, `nama_data_barang`, `id_jenis`, `id_satuan`, `id_kategori`, `keuntungan_minimum`, `diskon_maksimum`, `harga_beli`, `harga_jual`, `state`, `id_user_input`, `tgl_input`) VALUES (8, 'BR0000005', 'Tinta Epson 001 Cyan', 5, 2, 3, '10', '10', 64000, 72000, 'aktif', 1, '2023-12-24 04:05:42');


#
# TABLE STRUCTURE FOR: faktur
#

DROP TABLE IF EXISTS `faktur`;

CREATE TABLE `faktur` (
  `id_faktur` int(10) NOT NULL AUTO_INCREMENT,
  `id_distributor` int(10) NOT NULL,
  `nomor_faktur` varchar(100) NOT NULL,
  `tgl_faktur` date NOT NULL,
  `tgl_input` datetime NOT NULL,
  `catatan` text NOT NULL,
  `state` enum('aktif','tidak') NOT NULL,
  `id_user_input` int(10) NOT NULL,
  PRIMARY KEY (`id_faktur`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `faktur` (`id_faktur`, `id_distributor`, `nomor_faktur`, `tgl_faktur`, `tgl_input`, `catatan`, `state`, `id_user_input`) VALUES (5, 1, '0019920', '2023-01-01', '2023-12-20 04:23:35', 'OK', 'aktif', 1);
INSERT INTO `faktur` (`id_faktur`, `id_distributor`, `nomor_faktur`, `tgl_faktur`, `tgl_input`, `catatan`, `state`, `id_user_input`) VALUES (6, 1, '00012', '2023-12-24', '2023-12-24 04:06:22', 'Barang di Gudang', 'aktif', 1);


#
# TABLE STRUCTURE FOR: item_faktur
#

DROP TABLE IF EXISTS `item_faktur`;

CREATE TABLE `item_faktur` (
  `id_item_faktur` int(10) NOT NULL AUTO_INCREMENT,
  `id_faktur` int(10) NOT NULL,
  `id_barang` int(10) NOT NULL,
  `qty` int(100) NOT NULL,
  `id_satuan` int(10) NOT NULL,
  `disc` float NOT NULL,
  `pajak` float NOT NULL,
  `harga` int(100) NOT NULL,
  `jumlah` int(11) NOT NULL,
  `tgl_input` date NOT NULL,
  `id_user_input` int(10) NOT NULL,
  `state` enum('aktif','tidak') NOT NULL,
  PRIMARY KEY (`id_item_faktur`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `item_faktur` (`id_item_faktur`, `id_faktur`, `id_barang`, `qty`, `id_satuan`, `disc`, `pajak`, `harga`, `jumlah`, `tgl_input`, `id_user_input`, `state`) VALUES (6, 5, 4, 10, 2, '1', '11', 75000, 825000, '2023-12-20', 1, 'aktif');
INSERT INTO `item_faktur` (`id_item_faktur`, `id_faktur`, `id_barang`, `qty`, `id_satuan`, `disc`, `pajak`, `harga`, `jumlah`, `tgl_input`, `id_user_input`, `state`) VALUES (7, 6, 6, 5, 2, '1', '1', 55000, 275000, '2023-12-24', 1, 'aktif');
INSERT INTO `item_faktur` (`id_item_faktur`, `id_faktur`, `id_barang`, `qty`, `id_satuan`, `disc`, `pajak`, `harga`, `jumlah`, `tgl_input`, `id_user_input`, `state`) VALUES (9, 6, 5, 5, 2, '1', '1', 55000, 275000, '2023-12-24', 1, 'aktif');
INSERT INTO `item_faktur` (`id_item_faktur`, `id_faktur`, `id_barang`, `qty`, `id_satuan`, `disc`, `pajak`, `harga`, `jumlah`, `tgl_input`, `id_user_input`, `state`) VALUES (10, 6, 7, 5, 2, '1', '1', 55000, 275000, '2023-12-24', 1, 'aktif');
INSERT INTO `item_faktur` (`id_item_faktur`, `id_faktur`, `id_barang`, `qty`, `id_satuan`, `disc`, `pajak`, `harga`, `jumlah`, `tgl_input`, `id_user_input`, `state`) VALUES (11, 6, 8, 5, 2, '1', '1', 55000, 275000, '2023-12-24', 1, 'aktif');


#
# TABLE STRUCTURE FOR: item_surat_order
#

DROP TABLE IF EXISTS `item_surat_order`;

CREATE TABLE `item_surat_order` (
  `id_item_surat_order` int(10) NOT NULL AUTO_INCREMENT,
  `id_surat_order` int(100) NOT NULL,
  `id_barang` int(10) NOT NULL,
  `qty` int(100) NOT NULL,
  `harga` int(100) NOT NULL,
  `jumlah` int(11) NOT NULL,
  `tgl_input` date NOT NULL,
  `id_user_input` int(10) NOT NULL,
  `ppn` int(100) NOT NULL,
  `plus_minus` int(100) NOT NULL,
  `state` enum('aktif','tidak') NOT NULL,
  `flag` enum('boking','terkirim','terkonfirmasi') NOT NULL,
  PRIMARY KEY (`id_item_surat_order`)
) ENGINE=InnoDB AUTO_INCREMENT=31 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `item_surat_order` (`id_item_surat_order`, `id_surat_order`, `id_barang`, `qty`, `harga`, `jumlah`, `tgl_input`, `id_user_input`, `ppn`, `plus_minus`, `state`, `flag`) VALUES (29, 9, 4, 1, 500000, 555000, '2024-01-02', 1, 55000, 0, 'aktif', 'terkirim');
INSERT INTO `item_surat_order` (`id_item_surat_order`, `id_surat_order`, `id_barang`, `qty`, `harga`, `jumlah`, `tgl_input`, `id_user_input`, `ppn`, `plus_minus`, `state`, `flag`) VALUES (30, 9, 6, 1, 70000, 77700, '2024-01-02', 1, 7700, 0, 'aktif', 'terkirim');


#
# TABLE STRUCTURE FOR: item_surat_penawaran
#

DROP TABLE IF EXISTS `item_surat_penawaran`;

CREATE TABLE `item_surat_penawaran` (
  `id_item_surat_penawaran` int(10) NOT NULL AUTO_INCREMENT,
  `id_surat_penawaran` int(100) NOT NULL,
  `id_barang` int(10) NOT NULL,
  `qty` int(100) NOT NULL,
  `harga` int(100) NOT NULL,
  `jumlah` int(11) NOT NULL,
  `tgl_input` date NOT NULL,
  `id_user_input` int(10) NOT NULL,
  `ppn` int(100) NOT NULL,
  `plus_minus` int(100) NOT NULL,
  `state` enum('aktif','tidak') NOT NULL,
  PRIMARY KEY (`id_item_surat_penawaran`)
) ENGINE=InnoDB AUTO_INCREMENT=29 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `item_surat_penawaran` (`id_item_surat_penawaran`, `id_surat_penawaran`, `id_barang`, `qty`, `harga`, `jumlah`, `tgl_input`, `id_user_input`, `ppn`, `plus_minus`, `state`) VALUES (26, 7, 5, 1, 60000, 66600, '2024-01-02', 1, 6600, 0, 'aktif');
INSERT INTO `item_surat_penawaran` (`id_item_surat_penawaran`, `id_surat_penawaran`, `id_barang`, `qty`, `harga`, `jumlah`, `tgl_input`, `id_user_input`, `ppn`, `plus_minus`, `state`) VALUES (27, 8, 6, 1, 70000, 70000, '2024-01-02', 1, 0, 0, 'aktif');
INSERT INTO `item_surat_penawaran` (`id_item_surat_penawaran`, `id_surat_penawaran`, `id_barang`, `qty`, `harga`, `jumlah`, `tgl_input`, `id_user_input`, `ppn`, `plus_minus`, `state`) VALUES (28, 7, 5, 1, 60000, 66600, '2024-01-02', 1, 6600, 0, 'aktif');


#
# TABLE STRUCTURE FOR: log
#

DROP TABLE IF EXISTS `log`;

CREATE TABLE `log` (
  `id_log` int(100) NOT NULL AUTO_INCREMENT,
  `data` text NOT NULL,
  `status` varchar(10) NOT NULL,
  `date_input` datetime NOT NULL,
  PRIMARY KEY (`id_log`)
) ENGINE=InnoDB AUTO_INCREMENT=58 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `log` (`id_log`, `data`, `status`, `date_input`) VALUES (4, 'administrator', 'login', '2023-12-07 15:46:34');
INSERT INTO `log` (`id_log`, `data`, `status`, `date_input`) VALUES (5, 'administrator', 'login', '2023-12-07 16:10:56');
INSERT INTO `log` (`id_log`, `data`, `status`, `date_input`) VALUES (6, 'administrator', 'login', '2023-12-08 01:33:24');
INSERT INTO `log` (`id_log`, `data`, `status`, `date_input`) VALUES (7, 'administrator', 'login', '2023-12-08 13:30:39');
INSERT INTO `log` (`id_log`, `data`, `status`, `date_input`) VALUES (8, 'administrator', 'login', '2023-12-08 23:02:12');
INSERT INTO `log` (`id_log`, `data`, `status`, `date_input`) VALUES (9, 'administrator', 'login', '2023-12-09 03:04:28');
INSERT INTO `log` (`id_log`, `data`, `status`, `date_input`) VALUES (10, 'administrator', 'login', '2023-12-09 09:12:18');
INSERT INTO `log` (`id_log`, `data`, `status`, `date_input`) VALUES (11, 'administrator', 'login', '2023-12-09 11:58:19');
INSERT INTO `log` (`id_log`, `data`, `status`, `date_input`) VALUES (12, 'administrator', 'login', '2023-12-09 14:06:33');
INSERT INTO `log` (`id_log`, `data`, `status`, `date_input`) VALUES (13, 'administrator', 'login', '2023-12-10 00:20:22');
INSERT INTO `log` (`id_log`, `data`, `status`, `date_input`) VALUES (14, 'administrator', 'login', '2023-12-10 00:30:42');
INSERT INTO `log` (`id_log`, `data`, `status`, `date_input`) VALUES (15, 'administrator', 'login', '2023-12-10 05:17:47');
INSERT INTO `log` (`id_log`, `data`, `status`, `date_input`) VALUES (16, 'administrator', 'login', '2023-12-10 09:45:41');
INSERT INTO `log` (`id_log`, `data`, `status`, `date_input`) VALUES (17, 'administrator', 'login', '2023-12-10 12:14:40');
INSERT INTO `log` (`id_log`, `data`, `status`, `date_input`) VALUES (18, 'administrator', 'login', '2023-12-10 16:00:00');
INSERT INTO `log` (`id_log`, `data`, `status`, `date_input`) VALUES (19, 'Setya Yuli', 'login', '2023-12-10 16:03:54');
INSERT INTO `log` (`id_log`, `data`, `status`, `date_input`) VALUES (20, 'Setya Yuli', 'login', '2023-12-10 16:04:53');
INSERT INTO `log` (`id_log`, `data`, `status`, `date_input`) VALUES (21, 'administrator', 'login', '2023-12-12 03:07:33');
INSERT INTO `log` (`id_log`, `data`, `status`, `date_input`) VALUES (22, 'administrator', 'logout', '2023-12-12 03:09:09');
INSERT INTO `log` (`id_log`, `data`, `status`, `date_input`) VALUES (23, 'administrator', 'login', '2023-12-12 03:09:15');
INSERT INTO `log` (`id_log`, `data`, `status`, `date_input`) VALUES (24, 'administrator', 'login', '2023-12-12 13:56:55');
INSERT INTO `log` (`id_log`, `data`, `status`, `date_input`) VALUES (25, 'administrator', 'login', '2023-12-12 22:50:04');
INSERT INTO `log` (`id_log`, `data`, `status`, `date_input`) VALUES (26, 'administrator', 'logout', '2023-12-13 01:54:34');
INSERT INTO `log` (`id_log`, `data`, `status`, `date_input`) VALUES (27, 'administrator', 'login', '2023-12-13 01:54:58');
INSERT INTO `log` (`id_log`, `data`, `status`, `date_input`) VALUES (28, 'administrator', 'login', '2023-12-14 00:54:07');
INSERT INTO `log` (`id_log`, `data`, `status`, `date_input`) VALUES (29, 'administrator', 'login', '2023-12-14 04:26:07');
INSERT INTO `log` (`id_log`, `data`, `status`, `date_input`) VALUES (30, 'administrator', 'login', '2023-12-14 09:38:14');
INSERT INTO `log` (`id_log`, `data`, `status`, `date_input`) VALUES (31, 'administrator', 'login', '2023-12-15 11:18:15');
INSERT INTO `log` (`id_log`, `data`, `status`, `date_input`) VALUES (32, 'administrator', 'login', '2023-12-15 16:45:54');
INSERT INTO `log` (`id_log`, `data`, `status`, `date_input`) VALUES (33, 'administrator', 'login', '2023-12-16 01:24:33');
INSERT INTO `log` (`id_log`, `data`, `status`, `date_input`) VALUES (34, 'administrator', 'login', '2023-12-17 14:23:39');
INSERT INTO `log` (`id_log`, `data`, `status`, `date_input`) VALUES (35, 'administrator', 'login', '2023-12-19 13:51:32');
INSERT INTO `log` (`id_log`, `data`, `status`, `date_input`) VALUES (36, 'administrator', 'login', '2023-12-20 01:08:52');
INSERT INTO `log` (`id_log`, `data`, `status`, `date_input`) VALUES (37, 'administrator', 'login', '2023-12-20 07:34:45');
INSERT INTO `log` (`id_log`, `data`, `status`, `date_input`) VALUES (38, 'administrator', 'login', '2023-12-20 15:10:57');
INSERT INTO `log` (`id_log`, `data`, `status`, `date_input`) VALUES (39, 'administrator', 'login', '2023-12-24 04:02:16');
INSERT INTO `log` (`id_log`, `data`, `status`, `date_input`) VALUES (40, 'administrator', 'login', '2023-12-24 13:08:40');
INSERT INTO `log` (`id_log`, `data`, `status`, `date_input`) VALUES (41, 'administrator', 'login', '2023-12-24 22:36:30');
INSERT INTO `log` (`id_log`, `data`, `status`, `date_input`) VALUES (42, 'administrator', 'login', '2023-12-25 16:05:25');
INSERT INTO `log` (`id_log`, `data`, `status`, `date_input`) VALUES (43, 'administrator', 'login', '2023-12-26 08:36:34');
INSERT INTO `log` (`id_log`, `data`, `status`, `date_input`) VALUES (44, 'administrator', 'login', '2023-12-26 19:47:41');
INSERT INTO `log` (`id_log`, `data`, `status`, `date_input`) VALUES (45, 'administrator', 'login', '2023-12-27 08:31:02');
INSERT INTO `log` (`id_log`, `data`, `status`, `date_input`) VALUES (46, 'administrator', 'login', '2023-12-27 21:10:06');
INSERT INTO `log` (`id_log`, `data`, `status`, `date_input`) VALUES (47, 'administrator', 'login', '2023-12-28 09:15:51');
INSERT INTO `log` (`id_log`, `data`, `status`, `date_input`) VALUES (48, 'administrator', 'login', '2023-12-29 07:57:24');
INSERT INTO `log` (`id_log`, `data`, `status`, `date_input`) VALUES (49, 'administrator', 'login', '2024-01-02 00:12:05');
INSERT INTO `log` (`id_log`, `data`, `status`, `date_input`) VALUES (50, 'administrator', 'login', '2024-01-02 13:56:09');
INSERT INTO `log` (`id_log`, `data`, `status`, `date_input`) VALUES (51, 'administrator', 'login', '2024-01-02 17:19:29');
INSERT INTO `log` (`id_log`, `data`, `status`, `date_input`) VALUES (52, 'administrator', 'login', '2024-01-02 19:54:10');
INSERT INTO `log` (`id_log`, `data`, `status`, `date_input`) VALUES (53, 'administrator', 'login', '2024-01-02 20:10:35');
INSERT INTO `log` (`id_log`, `data`, `status`, `date_input`) VALUES (54, 'administrator', 'login', '2024-01-03 14:38:48');
INSERT INTO `log` (`id_log`, `data`, `status`, `date_input`) VALUES (55, 'administrator', 'login', '2024-01-04 22:36:18');
INSERT INTO `log` (`id_log`, `data`, `status`, `date_input`) VALUES (56, 'administrator', 'login', '2024-01-05 07:48:23');
INSERT INTO `log` (`id_log`, `data`, `status`, `date_input`) VALUES (57, 'administrator', 'login', '2024-01-05 20:26:51');


#
# TABLE STRUCTURE FOR: role_tabel
#

DROP TABLE IF EXISTS `role_tabel`;

CREATE TABLE `role_tabel` (
  `id_role` int(10) NOT NULL AUTO_INCREMENT,
  `id_menu` int(10) NOT NULL,
  `id_hak_akses` int(10) NOT NULL,
  `status_role` enum('aktif','tidak') NOT NULL,
  PRIMARY KEY (`id_role`)
) ENGINE=InnoDB AUTO_INCREMENT=79 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `role_tabel` (`id_role`, `id_menu`, `id_hak_akses`, `status_role`) VALUES (40, 1, 1, 'aktif');
INSERT INTO `role_tabel` (`id_role`, `id_menu`, `id_hak_akses`, `status_role`) VALUES (41, 2, 1, 'aktif');
INSERT INTO `role_tabel` (`id_role`, `id_menu`, `id_hak_akses`, `status_role`) VALUES (42, 3, 1, 'aktif');
INSERT INTO `role_tabel` (`id_role`, `id_menu`, `id_hak_akses`, `status_role`) VALUES (43, 4, 1, 'aktif');
INSERT INTO `role_tabel` (`id_role`, `id_menu`, `id_hak_akses`, `status_role`) VALUES (44, 5, 1, 'aktif');
INSERT INTO `role_tabel` (`id_role`, `id_menu`, `id_hak_akses`, `status_role`) VALUES (45, 6, 1, 'aktif');
INSERT INTO `role_tabel` (`id_role`, `id_menu`, `id_hak_akses`, `status_role`) VALUES (46, 7, 1, 'aktif');
INSERT INTO `role_tabel` (`id_role`, `id_menu`, `id_hak_akses`, `status_role`) VALUES (47, 8, 1, 'aktif');
INSERT INTO `role_tabel` (`id_role`, `id_menu`, `id_hak_akses`, `status_role`) VALUES (48, 9, 1, 'aktif');
INSERT INTO `role_tabel` (`id_role`, `id_menu`, `id_hak_akses`, `status_role`) VALUES (49, 10, 1, 'aktif');
INSERT INTO `role_tabel` (`id_role`, `id_menu`, `id_hak_akses`, `status_role`) VALUES (50, 11, 1, 'aktif');
INSERT INTO `role_tabel` (`id_role`, `id_menu`, `id_hak_akses`, `status_role`) VALUES (51, 12, 1, 'aktif');
INSERT INTO `role_tabel` (`id_role`, `id_menu`, `id_hak_akses`, `status_role`) VALUES (52, 13, 1, 'aktif');
INSERT INTO `role_tabel` (`id_role`, `id_menu`, `id_hak_akses`, `status_role`) VALUES (53, 14, 1, 'aktif');
INSERT INTO `role_tabel` (`id_role`, `id_menu`, `id_hak_akses`, `status_role`) VALUES (54, 15, 1, 'aktif');
INSERT INTO `role_tabel` (`id_role`, `id_menu`, `id_hak_akses`, `status_role`) VALUES (55, 16, 1, 'aktif');
INSERT INTO `role_tabel` (`id_role`, `id_menu`, `id_hak_akses`, `status_role`) VALUES (56, 17, 1, 'aktif');
INSERT INTO `role_tabel` (`id_role`, `id_menu`, `id_hak_akses`, `status_role`) VALUES (57, 18, 1, 'aktif');
INSERT INTO `role_tabel` (`id_role`, `id_menu`, `id_hak_akses`, `status_role`) VALUES (58, 19, 1, 'aktif');
INSERT INTO `role_tabel` (`id_role`, `id_menu`, `id_hak_akses`, `status_role`) VALUES (59, 20, 1, 'aktif');
INSERT INTO `role_tabel` (`id_role`, `id_menu`, `id_hak_akses`, `status_role`) VALUES (60, 21, 1, 'aktif');
INSERT INTO `role_tabel` (`id_role`, `id_menu`, `id_hak_akses`, `status_role`) VALUES (61, 22, 1, 'aktif');
INSERT INTO `role_tabel` (`id_role`, `id_menu`, `id_hak_akses`, `status_role`) VALUES (62, 23, 1, 'aktif');
INSERT INTO `role_tabel` (`id_role`, `id_menu`, `id_hak_akses`, `status_role`) VALUES (63, 24, 1, 'aktif');
INSERT INTO `role_tabel` (`id_role`, `id_menu`, `id_hak_akses`, `status_role`) VALUES (64, 25, 1, 'aktif');
INSERT INTO `role_tabel` (`id_role`, `id_menu`, `id_hak_akses`, `status_role`) VALUES (65, 26, 1, 'aktif');
INSERT INTO `role_tabel` (`id_role`, `id_menu`, `id_hak_akses`, `status_role`) VALUES (66, 27, 1, 'aktif');
INSERT INTO `role_tabel` (`id_role`, `id_menu`, `id_hak_akses`, `status_role`) VALUES (67, 28, 1, 'aktif');
INSERT INTO `role_tabel` (`id_role`, `id_menu`, `id_hak_akses`, `status_role`) VALUES (68, 29, 1, 'aktif');
INSERT INTO `role_tabel` (`id_role`, `id_menu`, `id_hak_akses`, `status_role`) VALUES (69, 30, 1, 'aktif');
INSERT INTO `role_tabel` (`id_role`, `id_menu`, `id_hak_akses`, `status_role`) VALUES (70, 31, 1, 'aktif');
INSERT INTO `role_tabel` (`id_role`, `id_menu`, `id_hak_akses`, `status_role`) VALUES (71, 32, 1, 'aktif');
INSERT INTO `role_tabel` (`id_role`, `id_menu`, `id_hak_akses`, `status_role`) VALUES (72, 33, 1, 'aktif');
INSERT INTO `role_tabel` (`id_role`, `id_menu`, `id_hak_akses`, `status_role`) VALUES (73, 34, 1, 'aktif');
INSERT INTO `role_tabel` (`id_role`, `id_menu`, `id_hak_akses`, `status_role`) VALUES (74, 35, 1, 'aktif');
INSERT INTO `role_tabel` (`id_role`, `id_menu`, `id_hak_akses`, `status_role`) VALUES (75, 36, 1, 'aktif');
INSERT INTO `role_tabel` (`id_role`, `id_menu`, `id_hak_akses`, `status_role`) VALUES (76, 37, 1, 'aktif');
INSERT INTO `role_tabel` (`id_role`, `id_menu`, `id_hak_akses`, `status_role`) VALUES (77, 38, 1, 'aktif');
INSERT INTO `role_tabel` (`id_role`, `id_menu`, `id_hak_akses`, `status_role`) VALUES (78, 39, 1, 'aktif');


#
# TABLE STRUCTURE FOR: t_customer
#

DROP TABLE IF EXISTS `t_customer`;

CREATE TABLE `t_customer` (
  `id_customer` int(10) NOT NULL AUTO_INCREMENT,
  `nama_customer` varchar(100) NOT NULL,
  `no_wa` varchar(20) NOT NULL,
  `alamat` varchar(100) NOT NULL,
  `nama_pimpinan` varchar(30) NOT NULL,
  `state` enum('aktif','tidak') NOT NULL,
  PRIMARY KEY (`id_customer`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `t_customer` (`id_customer`, `nama_customer`, `no_wa`, `alamat`, `nama_pimpinan`, `state`) VALUES (1, 'Pt Okata Onawa', '2147483647', 'Jalan Kebenaran', 'Suraji', 'aktif');
INSERT INTO `t_customer` (`id_customer`, `nama_customer`, `no_wa`, `alamat`, `nama_pimpinan`, `state`) VALUES (2, 'PKU Jatinom', '08123456789', 'Jatinom', 'Setya Yuli', 'aktif');
INSERT INTO `t_customer` (`id_customer`, `nama_customer`, `no_wa`, `alamat`, `nama_pimpinan`, `state`) VALUES (3, 'RSUD Waras Wiris', '0982768', 'Boyolali', 'Benny Danang K', 'aktif');


#
# TABLE STRUCTURE FOR: t_distributor
#

DROP TABLE IF EXISTS `t_distributor`;

CREATE TABLE `t_distributor` (
  `id_distributor` int(10) NOT NULL AUTO_INCREMENT,
  `nama_distributor` varchar(100) NOT NULL,
  `no_wa` varchar(20) NOT NULL,
  `alamat` varchar(100) NOT NULL,
  `nama_pimpinan` varchar(30) NOT NULL,
  `state` enum('aktif','tidak') NOT NULL,
  PRIMARY KEY (`id_distributor`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `t_distributor` (`id_distributor`, `nama_distributor`, `no_wa`, `alamat`, `nama_pimpinan`, `state`) VALUES (1, 'PT. Els Indonesia', '2147483647', 'Jl. Merdeka Timur,Komplek Perkantoran Terpadu Kab.Boyolali', 'Benny Danang K', 'aktif');
INSERT INTO `t_distributor` (`id_distributor`, `nama_distributor`, `no_wa`, `alamat`, `nama_pimpinan`, `state`) VALUES (2, 'PT Bima Sakti Sejahtera', '08212211221', 'Jl Kenangan Aku dan Dia', 'Setya Yuli', 'aktif');


#
# TABLE STRUCTURE FOR: t_hak_akses
#

DROP TABLE IF EXISTS `t_hak_akses`;

CREATE TABLE `t_hak_akses` (
  `id_hak_akses` int(10) NOT NULL AUTO_INCREMENT,
  `nama_hak_akses` varchar(20) NOT NULL,
  `state` enum('aktif','tidak') NOT NULL,
  PRIMARY KEY (`id_hak_akses`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `t_hak_akses` (`id_hak_akses`, `nama_hak_akses`, `state`) VALUES (1, 'Administrator', 'aktif');


#
# TABLE STRUCTURE FOR: t_jenis
#

DROP TABLE IF EXISTS `t_jenis`;

CREATE TABLE `t_jenis` (
  `id_jenis` int(10) NOT NULL AUTO_INCREMENT,
  `nama_jenis` varchar(100) NOT NULL,
  `state` enum('aktif','tidak') NOT NULL,
  `id_user_ipnut` int(10) NOT NULL,
  PRIMARY KEY (`id_jenis`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `t_jenis` (`id_jenis`, `nama_jenis`, `state`, `id_user_ipnut`) VALUES (1, 'Komputer', 'aktif', 0);
INSERT INTO `t_jenis` (`id_jenis`, `nama_jenis`, `state`, `id_user_ipnut`) VALUES (3, 'Asesoris', 'aktif', 0);
INSERT INTO `t_jenis` (`id_jenis`, `nama_jenis`, `state`, `id_user_ipnut`) VALUES (4, 'Printer', 'aktif', 0);
INSERT INTO `t_jenis` (`id_jenis`, `nama_jenis`, `state`, `id_user_ipnut`) VALUES (5, 'Tinta', 'aktif', 0);


#
# TABLE STRUCTURE FOR: t_kategori
#

DROP TABLE IF EXISTS `t_kategori`;

CREATE TABLE `t_kategori` (
  `id_kategori` int(10) NOT NULL AUTO_INCREMENT,
  `nama_kategori` varchar(100) NOT NULL,
  `state` enum('aktif','tidak') NOT NULL,
  `id_user_ipnut` int(10) NOT NULL,
  PRIMARY KEY (`id_kategori`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `t_kategori` (`id_kategori`, `nama_kategori`, `state`, `id_user_ipnut`) VALUES (1, 'High Quality', 'aktif', 0);
INSERT INTO `t_kategori` (`id_kategori`, `nama_kategori`, `state`, `id_user_ipnut`) VALUES (2, 'Midle Quality', 'aktif', 0);
INSERT INTO `t_kategori` (`id_kategori`, `nama_kategori`, `state`, `id_user_ipnut`) VALUES (3, 'Low Quality', 'aktif', 0);


#
# TABLE STRUCTURE FOR: t_menu
#

DROP TABLE IF EXISTS `t_menu`;

CREATE TABLE `t_menu` (
  `id_menu` int(10) NOT NULL AUTO_INCREMENT,
  `nama_menu` varchar(100) NOT NULL,
  `icon` varchar(100) NOT NULL,
  `link` varchar(100) NOT NULL,
  `state` enum('aktif','tidak') NOT NULL,
  `state_orgin` enum('parent','child') NOT NULL,
  `id_parent` int(10) NOT NULL,
  PRIMARY KEY (`id_menu`)
) ENGINE=InnoDB AUTO_INCREMENT=40 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `t_menu` (`id_menu`, `nama_menu`, `icon`, `link`, `state`, `state_orgin`, `id_parent`) VALUES (1, 'Adminstrator', 'icon-cube3', '#', 'aktif', 'parent', 0);
INSERT INTO `t_menu` (`id_menu`, `nama_menu`, `icon`, `link`, `state`, `state_orgin`, `id_parent`) VALUES (2, 'User', '', 'user', 'aktif', 'child', 1);
INSERT INTO `t_menu` (`id_menu`, `nama_menu`, `icon`, `link`, `state`, `state_orgin`, `id_parent`) VALUES (3, 'Seting', '', 'seting', 'aktif', 'child', 1);
INSERT INTO `t_menu` (`id_menu`, `nama_menu`, `icon`, `link`, `state`, `state_orgin`, `id_parent`) VALUES (4, 'Master Barang', 'icon-box-add', '#', 'aktif', 'parent', 0);
INSERT INTO `t_menu` (`id_menu`, `nama_menu`, `icon`, `link`, `state`, `state_orgin`, `id_parent`) VALUES (5, 'jenis', '', 'jenis', 'aktif', 'child', 4);
INSERT INTO `t_menu` (`id_menu`, `nama_menu`, `icon`, `link`, `state`, `state_orgin`, `id_parent`) VALUES (6, 'satuan', '', 'satuan', 'aktif', 'child', 4);
INSERT INTO `t_menu` (`id_menu`, `nama_menu`, `icon`, `link`, `state`, `state_orgin`, `id_parent`) VALUES (7, 'kategori', '', 'kategori', 'aktif', 'child', 4);
INSERT INTO `t_menu` (`id_menu`, `nama_menu`, `icon`, `link`, `state`, `state_orgin`, `id_parent`) VALUES (8, 'distributor', '', 'distributor', 'aktif', 'child', 4);
INSERT INTO `t_menu` (`id_menu`, `nama_menu`, `icon`, `link`, `state`, `state_orgin`, `id_parent`) VALUES (9, 'customer', '', 'customer', 'aktif', 'child', 4);
INSERT INTO `t_menu` (`id_menu`, `nama_menu`, `icon`, `link`, `state`, `state_orgin`, `id_parent`) VALUES (10, 'data barang', '', 'data_barang', 'aktif', 'child', 4);
INSERT INTO `t_menu` (`id_menu`, `nama_menu`, `icon`, `link`, `state`, `state_orgin`, `id_parent`) VALUES (11, 'Transaksi faktur', 'icon-stack2', '#', 'aktif', 'parent', 0);
INSERT INTO `t_menu` (`id_menu`, `nama_menu`, `icon`, `link`, `state`, `state_orgin`, `id_parent`) VALUES (12, 'Faktur', '', 'faktur', 'aktif', 'child', 11);
INSERT INTO `t_menu` (`id_menu`, `nama_menu`, `icon`, `link`, `state`, `state_orgin`, `id_parent`) VALUES (13, 'Item faktur', '', 'item_faktur', 'aktif', 'child', 11);
INSERT INTO `t_menu` (`id_menu`, `nama_menu`, `icon`, `link`, `state`, `state_orgin`, `id_parent`) VALUES (14, 'Stok Barang', '', 'stok_barang', 'aktif', 'child', 11);
INSERT INTO `t_menu` (`id_menu`, `nama_menu`, `icon`, `link`, `state`, `state_orgin`, `id_parent`) VALUES (15, 'Penjualan', 'icon-store2', '#', 'aktif', 'parent', 0);
INSERT INTO `t_menu` (`id_menu`, `nama_menu`, `icon`, `link`, `state`, `state_orgin`, `id_parent`) VALUES (16, 'Surat Penawaran Harga', '', 'surat_penawaran', 'aktif', 'child', 15);
INSERT INTO `t_menu` (`id_menu`, `nama_menu`, `icon`, `link`, `state`, `state_orgin`, `id_parent`) VALUES (17, 'Sales order', '', 'surat_order', 'aktif', 'child', 15);
INSERT INTO `t_menu` (`id_menu`, `nama_menu`, `icon`, `link`, `state`, `state_orgin`, `id_parent`) VALUES (18, 'Konfirmasi Order', '', 'konfirmasi_order', 'aktif', 'child', 15);
INSERT INTO `t_menu` (`id_menu`, `nama_menu`, `icon`, `link`, `state`, `state_orgin`, `id_parent`) VALUES (19, 'Permintaan Barang', '', 'permintaan_order', 'aktif', 'child', 15);
INSERT INTO `t_menu` (`id_menu`, `nama_menu`, `icon`, `link`, `state`, `state_orgin`, `id_parent`) VALUES (20, 'Tagihan / invocie', '', 'tagihan', 'aktif', 'child', 15);
INSERT INTO `t_menu` (`id_menu`, `nama_menu`, `icon`, `link`, `state`, `state_orgin`, `id_parent`) VALUES (21, 'Kwintasi', '', 'kwitansi', 'aktif', 'child', 15);
INSERT INTO `t_menu` (`id_menu`, `nama_menu`, `icon`, `link`, `state`, `state_orgin`, `id_parent`) VALUES (22, 'Permohonan Pembayaran', '', 'permohonan_pembayaran', 'aktif', 'child', 15);
INSERT INTO `t_menu` (`id_menu`, `nama_menu`, `icon`, `link`, `state`, `state_orgin`, `id_parent`) VALUES (23, 'Pembayaran', '', 'pembayaran', 'aktif', 'child', 15);
INSERT INTO `t_menu` (`id_menu`, `nama_menu`, `icon`, `link`, `state`, `state_orgin`, `id_parent`) VALUES (24, 'Pembelian', 'icon-cart-add', '#', 'aktif', 'parent', 0);
INSERT INTO `t_menu` (`id_menu`, `nama_menu`, `icon`, `link`, `state`, `state_orgin`, `id_parent`) VALUES (25, 'Permohonan Informasi Harga', '', 'permohonan_informasi_harga', 'aktif', 'child', 24);
INSERT INTO `t_menu` (`id_menu`, `nama_menu`, `icon`, `link`, `state`, `state_orgin`, `id_parent`) VALUES (26, 'Request Order', '', 'request_order', 'aktif', 'child', 24);
INSERT INTO `t_menu` (`id_menu`, `nama_menu`, `icon`, `link`, `state`, `state_orgin`, `id_parent`) VALUES (27, 'Penerimaan Barang', '', 'penerimaan_barang', 'aktif', 'child', 24);
INSERT INTO `t_menu` (`id_menu`, `nama_menu`, `icon`, `link`, `state`, `state_orgin`, `id_parent`) VALUES (28, 'Request Payment', '', 'request_payment', 'aktif', 'child', 24);
INSERT INTO `t_menu` (`id_menu`, `nama_menu`, `icon`, `link`, `state`, `state_orgin`, `id_parent`) VALUES (29, 'Sales & Marketing', 'icon-truck', '#', 'aktif', 'parent', 0);
INSERT INTO `t_menu` (`id_menu`, `nama_menu`, `icon`, `link`, `state`, `state_orgin`, `id_parent`) VALUES (30, 'Pengajuan Diskon', '', 'pengajuan_diskon', 'aktif', 'child', 29);
INSERT INTO `t_menu` (`id_menu`, `nama_menu`, `icon`, `link`, `state`, `state_orgin`, `id_parent`) VALUES (31, 'SDM', 'icon-user', '#', 'aktif', 'parent', 0);
INSERT INTO `t_menu` (`id_menu`, `nama_menu`, `icon`, `link`, `state`, `state_orgin`, `id_parent`) VALUES (32, 'Data Pegawai', '', 'data_pegawai', 'aktif', 'child', 31);
INSERT INTO `t_menu` (`id_menu`, `nama_menu`, `icon`, `link`, `state`, `state_orgin`, `id_parent`) VALUES (33, 'Pengajuan Cuti', '', 'pengajuan_cuti', 'aktif', 'child', 31);
INSERT INTO `t_menu` (`id_menu`, `nama_menu`, `icon`, `link`, `state`, `state_orgin`, `id_parent`) VALUES (34, 'Keuangan', 'icon-price-tags2', '#', 'aktif', 'parent', 0);
INSERT INTO `t_menu` (`id_menu`, `nama_menu`, `icon`, `link`, `state`, `state_orgin`, `id_parent`) VALUES (35, 'Laba', '', 'laba', 'aktif', 'child', 34);
INSERT INTO `t_menu` (`id_menu`, `nama_menu`, `icon`, `link`, `state`, `state_orgin`, `id_parent`) VALUES (36, 'Piutang', '', 'piutang', 'aktif', 'child', 34);
INSERT INTO `t_menu` (`id_menu`, `nama_menu`, `icon`, `link`, `state`, `state_orgin`, `id_parent`) VALUES (37, 'Realisasi Pengadaan', '', 'realisasi_pengadaan', 'aktif', 'child', 34);
INSERT INTO `t_menu` (`id_menu`, `nama_menu`, `icon`, `link`, `state`, `state_orgin`, `id_parent`) VALUES (38, 'Sudah Lunas', '', 'sudah_lunas', 'aktif', 'child', 34);
INSERT INTO `t_menu` (`id_menu`, `nama_menu`, `icon`, `link`, `state`, `state_orgin`, `id_parent`) VALUES (39, 'Belum Lunas', '', 'belum_lunas', 'aktif', 'child', 34);


#
# TABLE STRUCTURE FOR: t_satuan
#

DROP TABLE IF EXISTS `t_satuan`;

CREATE TABLE `t_satuan` (
  `id_satuan` int(10) NOT NULL AUTO_INCREMENT,
  `nama_satuan` varchar(100) NOT NULL,
  `state` enum('aktif','tidak') NOT NULL,
  `id_user_ipnut` int(10) NOT NULL,
  PRIMARY KEY (`id_satuan`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `t_satuan` (`id_satuan`, `nama_satuan`, `state`, `id_user_ipnut`) VALUES (2, 'Pcs', 'aktif', 0);
INSERT INTO `t_satuan` (`id_satuan`, `nama_satuan`, `state`, `id_user_ipnut`) VALUES (3, 'Unit', 'aktif', 0);
INSERT INTO `t_satuan` (`id_satuan`, `nama_satuan`, `state`, `id_user_ipnut`) VALUES (4, 'Box', 'aktif', 0);


#
# TABLE STRUCTURE FOR: t_surat_order
#

DROP TABLE IF EXISTS `t_surat_order`;

CREATE TABLE `t_surat_order` (
  `id_surat_order` int(100) NOT NULL AUTO_INCREMENT,
  `nomor_surat` varchar(100) NOT NULL,
  `id_customer` int(100) NOT NULL,
  `state` enum('aktif','tidak') NOT NULL,
  `flag` enum('input','terkonfirmasi','ditolak','terkirim') NOT NULL,
  `catatan` varchar(100) NOT NULL,
  `id_user_input` int(10) NOT NULL,
  `id_user_check` int(10) NOT NULL,
  `tgl_input` datetime NOT NULL,
  `tgl_surat` date NOT NULL,
  `ppn` enum('ya','tidak') NOT NULL,
  PRIMARY KEY (`id_surat_order`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `t_surat_order` (`id_surat_order`, `nomor_surat`, `id_customer`, `state`, `flag`, `catatan`, `id_user_input`, `id_user_check`, `tgl_input`, `tgl_surat`, `ppn`) VALUES (9, '0001/SPO/PROTIC/01/2024', 2, 'aktif', 'terkirim', 'OK', 1, 0, '2024-01-05 08:29:54', '2024-01-01', 'ya');


#
# TABLE STRUCTURE FOR: t_surat_penawaran
#

DROP TABLE IF EXISTS `t_surat_penawaran`;

CREATE TABLE `t_surat_penawaran` (
  `id_surat_penawaran` int(100) NOT NULL AUTO_INCREMENT,
  `nomor_surat` varchar(100) NOT NULL,
  `id_customer` int(100) NOT NULL,
  `state` enum('aktif','tidak') NOT NULL,
  `flag` enum('input','surat_pesanan','tervalidasi','terverifikasi','ditolak') NOT NULL,
  `catatan` varchar(100) NOT NULL,
  `id_user_input` int(10) NOT NULL,
  `id_user_check` int(10) NOT NULL,
  `tgl_input` datetime NOT NULL,
  `tgl_surat` date NOT NULL,
  `ppn` enum('ya','tidak') NOT NULL,
  PRIMARY KEY (`id_surat_penawaran`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

#
# TABLE STRUCTURE FOR: t_user
#

DROP TABLE IF EXISTS `t_user`;

CREATE TABLE `t_user` (
  `id_user` int(10) NOT NULL AUTO_INCREMENT,
  `nama_user` varchar(100) NOT NULL,
  `username` varchar(100) NOT NULL,
  `password` text NOT NULL,
  `state` enum('aktif','tidak') NOT NULL,
  `id_hak_akses` int(10) NOT NULL,
  PRIMARY KEY (`id_user`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `t_user` (`id_user`, `nama_user`, `username`, `password`, `state`, `id_hak_akses`) VALUES (1, 'administrator', 'admin', 'XuePs8IE/41N9eZzEN6bONQpXT3F2aCgGNhtJ7jehmvmOhLB1i+GNLC4qI3qoaztP0Hv1dnEFK7Kq44mczfcrA==', 'aktif', 1);


#
# TABLE STRUCTURE FOR: t_vendor
#

DROP TABLE IF EXISTS `t_vendor`;

CREATE TABLE `t_vendor` (
  `id_vendor` int(1) NOT NULL AUTO_INCREMENT,
  `nama_vendor` varchar(100) NOT NULL,
  `key_app` text NOT NULL,
  `nama_pimpinan` varchar(100) NOT NULL,
  `alamat_vendor` varchar(100) NOT NULL,
  `no_telp` varchar(20) NOT NULL,
  `email` varchar(100) NOT NULL,
  `logo` text NOT NULL,
  `moto` varchar(100) NOT NULL,
  `status_aplikasi` enum('online','offline') NOT NULL,
  PRIMARY KEY (`id_vendor`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `t_vendor` (`id_vendor`, `nama_vendor`, `key_app`, `nama_pimpinan`, `alamat_vendor`, `no_telp`, `email`, `logo`, `moto`, `status_aplikasi`) VALUES (1, 'Protic Indonesia', 'PstkFR9JSROm0Vi0WxM9AmO2mqSREQHpa+Gbn4gKu+A5A+oyuIIBKjG27i3LL4IMEk/o1BoUvH5tNVaXuK78Kd5/LsWcyyjGHSqMVGRXx6g=', 'Setya Yuli, Amd.Kom', 'Office: PT. Protic Care Indonesia - Ruko LA No.02 , Jl. Keniten, Tamanmartani, Kalasan, Sleman, DI Y', '0812345678901', 'protic.indonesia@gmail.com', 'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAI4AAAAwCAYAAADHPUINAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAJcEhZcwAADsMAAA7DAcdvqGQAABaeSURBVHhe7VsJdBvVuRZ72Mnq2JY0kjwjzYxmkSzHcWmLoUDZIYUT9vd4PWxtWV4hpSwB1NixtToQkrCX8B57ICxNSCGPEgqUUqC8PBL2JI4W20kIJCH7qvf9M1e2tVhWgLQnVN8590i62/z33u/+y70jy3eD5iFDh44/kuOCQ2Q5eJjFktmHFVRQQUnsI8vjDxS9ocu8aviPorftfFcgfCRIdCArr6CCgaFpsUNdrlsFrx66R/NFE6oamaaqoaGsuIIK8hHcl+enHqSqNw2tqblpuFtqvVTVwzt1/5RtINDnXq3tbJ6/5iBWuYJ/dYwfP2s/G99ap2jhNs0X+1z3xxP4RIp2I+301U/J+OrvyOj+2Jf4/bFXC51jsVxxAGtewb8g9hGkSWNBhNe1+o7lIMUmf+DOjD8wFenOLFl6kz9wh1Gm+Tu+QJu5rsCNR7J+DMyyWPZjXyv4voLng0fovthbMENJvb7DIISpWeIZHcmHPDPRd+T5KZkE8oFAVBdE+zscZ576y8gjD0tb3bcvdQVyyFTB9wiiOrkevss7/sBdjDAdBjH6yFI8EaGyBKLf1F73RReJ4uSmDLTXilqnlrDx8c+HDrWxR1XwfQHHBUdr/shCWvQ+UpgaRNEj74tK6GeS1HqC3x87xuMNHy2Kk06UpMmnSGooDL9np2nCTKJRon6geT6ocsVGUf89tcLYhM39+GqeP8J4YAV7P3y+mAwN8VeTNKYPo2rhd3U9cpxWHxsr+SICq1oAMm1+/5QGXY8dq2qhd03/xySe4ffo0b9y7jaR6qZq3T9J2txzPxrhdBuNK9h7wfO/tWr+6DuBMTMM0ihq+BkiQSmyDATZ387reug0zRfZkjV19ClroZct8izjsDBpFc4HeZ55L1B9iNGogr0PdDYjq+2vBsbcQ+Zll6qGzlLVsJUVf2PIerhRVSMtuj9qmDAQabtXazufFVsSNuGhVE3d418M9xzOsnIgy9MP86rhZxU1sgBR2iv9E4i9QPKGHh3s2qO5Obi/orT/HON7SVFDr+b2EXqV8iWp/TxWfbchy6Hr0Nd8r9r+J5LJq7Q/P5q/ZiQrHhClxtY/KWr7Aq8amitJk36MZjljDQSuOEDRw1dSPRqHKIZOo7M2VjwIMvtg/LOzzzdkV9ufs1jGlxf5BoPBfSWl7VwyK6o/vhha52RWlAOeb5Orq68wtIMkhU4ACeYi2pqP+r2JfsOpnuPRJp8jyMFGu3ui0yIHD1T90Xb0v9UkT3QxTRr1k7Q61bRN+Pxjz0DE6Rim+iLb6hvuNnyl3DTNMIV6/ZTXFK39aZ6/uehi0XWIrIZiZDrrG6YX9OEjM+qPp2FK54PoV7Jmg0JSIz/GmOdp/tiabF9Gf9DW2HxvY5xzBSl0DKteABob6myvb7innzyFqb5hhuErymrrBWiWQxwam6KFp1M9Gp8st11TxsLvJ2uTg5D7NZLVH8jOCckO9wLzic3+xPDhNxRdk14EAsFDVD3yIVj3rqRNGsuyDdDiK1poss8ff1nTY295PJHDA4H7DsAOmE+LUA+zZnxmE36TECBVUkOf+PxA9cXmwKl+Cc/YZE5qdAsccAf1n+G4IUlOeC9tcz/aU6Udajy0H+gaA/W/NP2lOJ4xLS9Nz5CWJDMIrfJ0sTszgzgYAxZpGzn4dNaU309D4734nJFR9egqRQndThqYNS+CWft5vW1TEQh80jcHuf2RTPSJMdNh6C+xPfdnjXsBuYZhbNuydSmRbOaRRt9YA2PuNky9rP6uKHG8ejhObWh8IA6IX5o4WJfnNV98Y9/a5cuOTVo/NQO557kbW52sWS4MbSO1jcNu+8Srt/2QZVs83sknwUmerftiH5CfEsDEYlJ30h1VU1PHwShji9l3+Nc/kWahxTR3zHQMyhiYccIMpn/Nay1+eg5C9P1SnHBql0Nc2cnpRxkP74cscagv9Lte9UUvVP2RM7MJPti52HGfMTO4A5HdCWhWMLmMODvQxy5VizwLTXFObj+Ri1C2gyYTc9GNzVHU78pkMvt4vKEzNF94CxENC5DB7rwLcp3V258vOh7k+xvJXD9megYac5nFYmrq/qANCDlO9vvvMNphXs7Goj5NpMH8bsqO1e+P0zhP8/iDNaxpL3aHOHQVpOihx+sbaE2I1OEtNO5euZF89Ew9ssNcPygAf3Qxa54L0jaSt+0WTQv/iH4ryqRmCP0kBPnUZCCpMFqU2EZFb79o/Pjx+x199IOHo8M1pYhTmLJnOyZxhMDkRkMAINPcPKTbKXalbO7rMoFAzjVFL3EgB32SXWZFvSCyoO/1JCcW6W3SiqzIQB9xYjvRxy5ZaW9lRTnQtGgbTO021NvhVtrGYVcV+AoUOWKB3qNn+erjWyHfrbI1OIwV90IQgj5ZjUyFKd1OWsSrhB5ubp45hBUPCGjN20zixNYVG2s+doc4otoSwOYyNjSUwEbIPp4V5cDrD59vHL1o0bXQOmGWnQtyHNGBi9gva+Gopsc/JMKYC2UuumleYpvpHRxqIzd1kIqFxpnSW6fc1Escb4tuCACka8Th3Q5pddLGz05arQezbAO5xIl9RX4BK+oFjQF1VvshN+psEcVpw1mRgXziwCGMFbuIdbvbT8bEwpxOoejvuWpsKlbUC7f7tuNJcxmmUQt/KYrtOc/qD5snWKNq4U6qS9qw/5iLgeTEeOELGsT5uthY81EucazW6w6WYMoxNsxBfLMot17OiooCmmicooRPLG32QAg8dJbuJ/vfRxhKdJUAdbxNVaP3kJBk2siLxyJsNg/5cokxWCItBVW4WRAm17Knw0GWh4E467ocniVfuVw51xHlEIe0pkkco876/MUslziiN3w+5mErJnaX5G2/K78O+jlM08N/xhjQT8cGql8qgiFCI1p7jK5rQITNbrm1aNCRxZ4kDs0jtLHhxMNErR458ldGcPKNQQ+CLZ1Du6KYBqE8PHCDYIaChl3GTruP1PnuEsesH98Bx7qD+jEEABJ2dShM1UakbfSdZRvIJU5xUwVH9ThM2kYfmSo9srCxMZhzIp1PHDy/hRX1wusNn4RxvmnOQTwjCKEC7UALifZbTM1GsswqsRsJwX1FMdxE/grSDviSF5cyP3uaOKizljYuNs6baPfNiSNJrccgdl9JB36GsHkLTYkeBNOyrs7batwtkaC0Y7EI23ePOHT1gIXVIun+2oZAZIFzvL7bKW1aWu2ys2wDWeIQKdDPZlkJzyDiGUkJT4EJuB8T9neSxReYkhHFlrPpFRDW3EA/4kBmaFA9uhA+2gP4fS8l9P8A8j7K+nNwdkOsaQ6yk5/Vfo381LKuTHwI10GEnSDOufj5TyOO6Zd2IPoMPUlamhXtHuziLdVYxL+Q6jJvtostNogD8wU73dXYaE5SVVXsUEVtmwPzReq6aJvCRKElogs9sgo7u/fwL4sMBtplmCpx+9IaO0VFvegljuGIUz93I1H4aqYxYx/MNIx9AGO4M+NVw5NYsxz0EYfC8Q60m4Z2vzdSw9j7jfCTSIPx7MDzHqyqmlBwLEDQ9eBR6CNl+izRdQ5HK8eKiqK5ecH+Xi38G8i9DZtvK0h9Oisqij1NHJgoBBDkGEcWYdbLPCTMA9TyIxRKYsctpZ1YuNjmgmPAiEJCL0NAQ7XR5EGA7mJmrTDF2aIYpHkGoeDPjIf3w2KLfOByu/uqFU5pK4iztbOay6mTJY4fxCA5IfcCdiY0X/WFX9b00DzkPwdH7losVcFZCaEfcTDOeEbRo0uxGV5EZDGHjiEg6y4aD7TvMg8cWtasAEY/Svhq9LEZ/uB2OJv/xYqKwioHh9FmYX4jiNOmsKKi2JPEoUgTG+t9cwPGdoDQl7KiopDUtuM9nhYP+4kuocZJxdNievXIDZjQGbC/W/ubHTMMp8MomAfkwyw8mo0wzIWMrWMC9Ev0ykX2cG26caBm7sxYBCry+jrvxAFfo0g5PEnYwgyI83XnSM7Hsg30EgcagXY5nM2xLqlFcLuDIg1MwneY3JI7v484LBzXwg8Iwq0S722tQyh/lik3dqIWTvJym8yaFYXLdeOR2TmiYMLrLfSXspCUthmYP/iCMPd65C2OKx2O70ni0AGkokTGZV+0A6ETNI+sMAcILi6ANVqMOn9CIHSnkelRW1Q4t+sxibfTb0Vrj+KBhqNrmqzoFmiU32NX3420SIFPInlD06xN1xlhMi0kdvqGhkZS8ff0JjIVqL8S9TuRHvb5ptyGfn9DbUqhk/NMWumUtq0l4jjFNZ+N5nOuDfoTB5PzZVPTUznhejnIJw42Qo4PAzlvM89l4DjqkeeRNaAfQifKkONW6svYWD7SvNF2UQy6ncrNVZwn6JDl1quQFyeNbhI+kpHU8CnFF7QPe5Y4JrD2rdmxQuP+AVpoIgIBl8s1YZQgBF0gy+9ULZqsB7loXeHPfgqbO3MIvvw31Do6N6EobRebZxf9iRMFcUJ3S0rofrqTgpqDyjLDTpo4tL/aX9/RAmF7ExbjFoSw53nk9jOHDbumLKex01o34SunlPnCJWdWI/UgsqLQnBUbyCNO0XB8MOQTp1g4js3wJCYTZKAT6mg7yx4QXrV9IvlF5lXFNCLcS6ov9BR26AuqFtpBk05l5AdiI05kzUriH0EcAjTrs/VwIUg+Xz1p2shcyP8E5JxT3zCVWZwZlD+fNLxx5Kyq4V+z9gag8keAZQjT+nyWrKlS9dj/6fXhX2MwJ1iaC+9avgX2gXa5eQXn2QptA8JIGfg4u7o4z9uf5b3cRZNHhB7T9BAG2YGoKfdwrxww4txBk0ERJEh+D8ddkmM2BKFF0vTwFtNhfjADrTmh2FlPf5CmUn3xP9LkNzbNZOkhw+HWMZ+Y1we9WvugWjcLRpypgTEw89AI5YzVII4WupeISmsmipOxvqWJIzqDbsgeRtpKPijJnJWd+jFlj8bhCqhGg1Gjrq0yvvSDyxU+Ekz7opizSyqN7m68SuiFKs2MNDqNS0nPhUusTvXjKs7RabEMeoxOuM9iOWBpjdPd5fBc28O5Y2ugYb5EQghOpCH/ZnvCJkQWWyw5l5R0L4YBtvobppLqbx3oDqkUyK8jU4GNECMTgok+gw7nWDFDcF/4KzfAb6HnTFH10A3Zk/JSIPVuqP/6Kdj1cSPRd1lrvw3FJRcwHySnorSfavSjx9rKGavhs2I81AbzFIV/8oNSh5L9ATflWqx9r9yUiDDYWLeyKias1ltq8zs138MJYULjWwvDa4qqDJ+g1zkmjZC0uf8nxXle6bJ7Zidt/FQ4t/8JQlwDLXJ1yu7+t06rexyllJ2/mPJ6QJakXehI2z0vrocvs4VXDS1DpKFEporOcNDm5KDF8s3CxAr+8bCLk6uxEw3vvwziHJSwuaeRtthQpxhpC69ktiLRZ5oTMyDVlyzt2szKNqIeOcD9CZNN5N+AeOu7qgO7rU0q+Ceime6q/NGnNV/HNiJLKeJkmpv3T3OeCd0Oacsqp2lq+qcVIMEqluh7fnl+Yj7OzhTMVP4FJyFpbTq4xymP35OkMp7hkM5L2GwDnuHs7aB3nbodnitXD/uO/yBAYSRs5LZcrVNIHEK6RvXQpSRpimJkKDeR9jG0DedJZQYwUavsYjXqrU5ahZxriu8Si2X5wG6HuLaz1nUqy/regf7LBj8y/km1ewTL+m5gtRpO6OsUjvZdQRQnDvk5MC2rvy1xDM2Ez0Qtf1NGznWKs1jhVKq6neKS5SAQyyrAe4HAASlOODtpd1/VZRcuX+GUL2JFA4Kc8C67dCnaXAqNdjMmdWWqtu44VlwU8yyWg+CzXZbm3L9C/csXVlUVvZog0Atq6RrRvaimzpa0ui9N2cUr0ra6M/PfN8rH8uq6emj0X6RtwiUg8yUsuyjoqiZpdTSnrfzP8YzLELiMZkUFyBibQzqGXA2WVRQph6AnOPcvEahcmap1n0KamBUNDLrJRQi5EE7yTtNkFSdOV3X1IXCK5/Y4xZ0UERUjxWBpJUjzNXweOM0vZ0rcGJdDnHRNzfCUzb0OzvcbcM5fgAZbQn+/IbPKquSA/hgIgl0Lf+wlEGf2Cof4OhZpTXK0o5lVKQC1STuFCWmHNB/EeRlqf/5yG38jRZmsSg4oH5M/CeN7CsHEi5DvpZRVWEaysioF+KS6ekSipu6RtMMzG2OYjs05r9PqumCgxabL4aSVX4znPNZlEx7qrOaMvx4Vw0pOHo31WvVpCc29+AjrMMg7K2EXXoUfOydVKzy31uXF0MuA19t+Ol0zGKeiWeIooYetCItZFXMSa4QTsKCbWES0W4l8H3KUsbNeW1LrKvnXm3KIs9TprMLCfJhdxGQ1Nw6/n8h/t4dgyG73HE2TmH3HuZNrHgJNsjxR48y5YM0Cbfbtsrl/hAX9KOuHkc+VdohdCZunqF9E5q/TxrdijPNZlsUgdQlT8dkorgmL9k7SKl6w3M6fnqit+x0i100rRjkLjlEIn/G+kQm7O5m0i5f1cJ5jWXZRDDaPxrvfduHWLlvdzSwLvh/fDM26lf0sDTpQ0n2xZ+AobzffejcuBV9Bfs77GzTpmMie3TVXpKEoJMeE/m15lb34i9D9UA5xelyuUTBVi7KqugcmJGUXHso/hSYQCTptrv8AUXpWyrIxpq5A4JBSxCFTmKh1XYld+CqpfMqDyTkEciUHIs5CzE+nVZjwUZXVuNiEbEdBMzxSTKYslo10/DRl87wPDTUH6Wn6zxkW7pHMSFPOfHxmoQiXvwkbYR5M1YLldvfxA5nCweZxKcqh4ZLdo+29d3V0AZ12ihvYz/Ig6aEO3RddZL6rE9uYf/y9i8LyWn56l1PaVa65IvO0HmE5SPPmktGuBtZVSZSjYleQxuGE5R+zqAhaYVjKzj9Jr6QaFfKwpMo1CqRPYNHP6HEKjV2cNA4LtGFZteMkVqUAKZ63EtnSNv6MFMc3pW3uc7EQC7v53Lu1LBZjsTttwkTSIvQ7YbcPBfGeHUgm0oSJansgWeue2WV3/RBaR0nVSmM/GmGnhS5qymeBxEvsrp901nA+mLjroX0+GKj/webxPbgfCasQTtr553u4umPTXN0PEra66+mgllUpH5LU4gd53lD16Daen1owQZ/a7S5M5prBzBVpJTrHWUf14CPAR8p5WasU1ppvBz420IQQaFHg1EHDWA1y03+0UvA/yIk3KuTB8NHswp0JOx9P2uvC2Nn3Qa45qZGOAd8JJkcYftEMkCaGvuMp+BXpGv4XZJJYlRyQ+QNRzsv6HaTdoHEmDiQTwTAXVn5q0lp3BzRJNGV1zwQhzl0wgK/2BcaZ5IRZy1Af4wjheXetlEcW1U7lzOPSoUMReUlzMc6ONOYFm/ENKIXXWPHugV5y9mqhR4vdmxgOoL1uNoXV/bUO/V4Dp4pelSAHGLt57RdO6S9wDv+wwGL5Lu+8vjWCeVcc5eCbtNldPGWxlP0WwF552r5kRF2ATn1J6xBhyH8hTxzmaHmPQ/y4ixPfhvr7LateQQUmSOukOeGRr0AcaJadq1zS/yLaeHMpHM1Ph3ESq1ZBBYWgCKKL8yxK2zzrFg9gYyuooCgQSuowT593cq5TWFYFFQyOBc2W/ZNWdzBpEz4pdVZRQQUFWCvLwxDaLuisdl7IsiqooDwst9ur0zb3n7s5oeIYV7B7WEY3rPa6MJGITkRZdgUVlAaRZeko54nLauv+PXvxWEEFZYGO4j8eWXf0zApx9nJYLP8PupulFi60tCkAAAAASUVORK5CYII=', 'Kami Melayani Sepenuh Hati', 'online');


